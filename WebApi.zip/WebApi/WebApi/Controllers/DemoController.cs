﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi.Models;


namespace WebApi.Controllers
{
    public class DemoController : ApiController
    {
        [HttpGet]
        [Route ("api/Demo/getMyname")]
        public string getMyname()
        {
            return "Ganesh web api";
        }
        [HttpGet]
        [Route("api/Demo/Getkeyword")]
        public IEnumerable<string>Getkeyword()
        {
            string[] data = new string[] { "data1", "data3" };
            return data;

        }

        [HttpPost]
        [Route("api/Demo/GetBook")]
        public HttpResponseMessage GetBook([FromBody]  Book source)
        {
            if (source.BookName == null)
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "ERROR");
            string[] data = new string[] { "data1", "data3", source.BookName, source.AuthorName };
            HttpResponseMessage respons = Request.CreateResponse(HttpStatusCode.OK, data);
            return respons;

        }
    }
}
