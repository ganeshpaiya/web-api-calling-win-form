﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Net;

using System.Web.Script.Serialization;
using System.Linq;

namespace getApi_WindowsFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          this.PopulateDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string URI = "http://localhost:51411/api/Home/GetCustomers";
            //GetFileInformation(URI);
        }
        //private async void GetFileInformation(string url)
        //{
        //    HttpClient cli = new HttpClient();
        //    cli.DefaultRequestHeaders.ExpectContinue = false;
        //    List<Customer> filesinformation = new List<Customer>();
        //    using (var client = new HttpClient())
        //    {
        //        using (var response = await client.GetAsync(url))
        //        {
        //            if (response.IsSuccessStatusCode)
        //            {
        //                var fileJsonString = await response.Content.ReadAsStringAsync();

        //                dataGridView1.DataSource = JsonConvert.DeserializeObject<Customer[]>(fileJsonString).ToList();
        //            }
        //        }
        //    }
        //}
        private void PopulateDataGridView()
        {
            string apiUrl = "http://localhost:51411/api/Home";
            object input = new
            {
                Name = "",
            };
            string inputJson = (new JavaScriptSerializer()).Serialize(input);
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.UploadString(apiUrl + "/GetCustomers", inputJson);

            dataGridView1.DataSource = (new JavaScriptSerializer()).Deserialize<List<Customer>>(json);
        }
    
        public class Customer
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public string Address { get; set; }
            public string Phone { get; set; }

           
        }

    }
}
